<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Kunin at linisin ang data mula sa form
    $firstName     = trim($_POST['first_name'] ?? '');
    $lastName      = trim($_POST['last_name'] ?? '');
    $email         = trim($_POST['email'] ?? '');
    $contactNumber = trim($_POST['contact_number'] ?? '');
    $comments      = trim($_POST['comments'] ?? '');

    // 2. I-save sa Database (Opsyonal)
    if (!empty($firstName) && !empty($lastName) && !empty($email) && !empty($contactNumber) && !empty($comments)) {
        try {
            require 'db-connection.php';
            $sql = "INSERT INTO contacts (first_name, last_name, email, contact_number, comments) VALUES (?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$firstName, $lastName, $email, $contactNumber, $comments]);
        } catch (PDOException $e) {
            // Pwedeng i-log ang error kung kailangan
        }
    }
} else {
    // Kapag direktang binuksan ang file nang hindi nag-submit
    header("Location: contact.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Result</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            padding-top: 40px;
            margin: 0;
        }
        .container {
            background-color: #ffffff;
            width: 480px;
            border: 1px solid #ccc;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .header {
            background-color: #d8d8d8;
            text-align: center;
            padding: 20px;
            border-bottom: 1px solid #ccc;
        }
        .header h1 {
            margin: 0;
            font-size: 32px;
            font-weight: bold;
            color: #000;
        }
        .content {
            padding: 25px;
            color: #333;
            line-height: 1.5;
        }
        .content h3 {
            margin-top: 0;
            margin-bottom: 15px;
            font-size: 18px;
            color: #000;
        }
        .content p {
            font-size: 14px;
            color: #555;
            margin-bottom: 15px;
        }
        .field-list {
            margin-top: 20px;
            font-size: 15px;
        }
        .field-item {
            margin-bottom: 12px;
        }
        .field-label {
            font-weight: bold;
            color: #000;
        }
        .error-text {
            color: #666;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="header">
            <h1>Congratulations!</h1>
        </div>
        
        <div class="content">
            <h3>You have successfully created a form.</h3>
            
            <p>Here is the form information you entered. Check to make sure each field comes through.</p>
            
            <p>If any of your form fields are not coming through, check the name attribute. The name attribute sets the field name for the PHP script, so if it is incorrect, then your form field will not display.</p>

            <div class="field-list">
                <div class="field-item">
                    <span class="field-label">First Name:</span> 
                    <?php echo !empty($firstName) ? htmlspecialchars($firstName) : '<span class="error-text">The first name field is not coming through the form.</span>'; ?>
                </div>

                <div class="field-item">
                    <span class="field-label">Last Name:</span> 
                    <?php echo !empty($lastName) ? htmlspecialchars($lastName) : '<span class="error-text">The last name field is not coming through the form.</span>'; ?>
                </div>

                <div class="field-item">
                    <span class="field-label">Email:</span> 
                    <?php echo !empty($email) ? htmlspecialchars($email) : '<span class="error-text">The email field is not coming through the form.</span>'; ?>
                </div>

                <div class="field-item">
                    <span class="field-label">Phone:</span> 
                    <?php echo !empty($contactNumber) ? htmlspecialchars($contactNumber) : '<span class="error-text">The phone field is not coming through the form.</span>'; ?>
                </div>

                <div class="field-item">
                    <span class="field-label">Comments:</span> 
                    <?php echo !empty($comments) ? htmlspecialchars($comments) : '<span class="error-text">The comments field is not coming through the form.</span>'; ?>
                </div>
            </div>
        </div>
    </div>

</body>
</html>