<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Groove Guitars - Home </title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <header>
        <img src="images/groove-guitars-logo.png" alt="Groove Guitars logo with a guitar with a groovy flower print"
            width="570px" height="269px" class="logo">
    </header>

    <nav>
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="grooves.html">Grooves</a></li>
        </ul>
    </nav>

    <div id="home-hero">
        <h1>Find your Groove!</h1>
    </div>

    <main>
        <h2>Welcome to Guitar Groove!</h2>

        <p>At Groove Guitars, we are more than just a guitar store; we are a haven for musicians and enthusiasts alike,
            where the art of crafting and playing guitars merges seamlessly with the rhythm of your life. Nestled in the
            heart of the city, our store is a haven for those who live and breathe music.

            At Groove Guitars, we don't just sell guitars; we celebrate the beauty of music, craftsmanship, and the
            enduring
            power of melody. Whether you're a professional musician or a weekend strummer, our store is a place where
            you
            can find your rhythm, explore new horizons, and groove to the beat of your own tune. Visit us today and
            embark
            on a musical journey that will resonate with you for a lifetime.</p>

        <h2>Hours of Operation</h2>

        <p>Stop by our store! The right guitar for you makes all the difference. We specialize in matching players to
            the
            right guitar. We can help you find your groove.</p>

        <table>

            <tr>
                <th>Day</th>
                <th>Hours</th>
                <th>Services Available</th>
            </tr>

            <tr>
                <td>Sunday</td>
                <td>11am to 3pm</td>
                <td>Sales Only</td>
            </tr>

            <tr>
                <td>Monday</td>
                <td>11am to 9pm</td>
                <td>Sales, Lessons, Repairs</td>
            </tr>

            <tr>
                <td>Tuesday</td>
                <td>11am to 9pm</td>
                <td>Sales, Lessons, Repairs</td>
            </tr>

            <tr>
                <td>Wednesday</td>
                <td>11am to 9pm</td>
                <td>Sales, Lessons, Repairs</td>
            </tr>

            <tr>
                <td>Thursday</td>
                <td>11am to 9pm</td>
                <td>Sales, Lessons, Repairs</td>
            </tr>

            <tr>
                <td>Friday</td>
                <td>11am to 6pm</td>
                <td>Sales, Lessons, Repairs</td>
            </tr>

            <tr>
                <td>Saturday</td>
                <td>11am to 6pm</td>
                <td>Sales, Lessons, Repairs available until 3pm</td>
            </tr>
        </table>

        <h2>How Can We Help You?</h2>

        <p>Looking for a certain guitar? Let us know and we can help you look. Need help with guitar and bass lessons?
            Let
            us know your skill level and hours available and we will match you with an instructor.</p>

        <form action="process.php" method="POST">
            <label for="first_name"> First name: </label>
            <input type="text" name="first_name" id="first_name" required>

            <label for="last_name"> Last name: </label>
            <input type="text" name="last_name" id="last_name" required>

            <label for="email"> Email: </label>
            <input type="text" name="email" id="email" required>

            <label for="contact_number"> Contact number: </label>
            <input type="text" name="contact_number" id="contact_number" required>

            <label for="comments"> How can I help you?: </label>
            <textarea name="comments" name="comments" id="comments" required></textarea>

            <input type="submit" value="submit">
        </form>

    </main>


</body>

</html>